package sk.train.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcTest_H2 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Class.forName("org.h2.Driver");
		
		Connection con = null;
		
		try {
			con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
			System.out.println(con.getMetaData().getDatabaseProductName());
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from hr.employees");
			System.out.println(rs.getMetaData().getColumnCount());
			while (rs.next()) {
				System.out.println(rs.getString(1) + ":" + rs.getString("last_name"));
				
				
			} 
			
			PreparedStatement ps = con
					.prepareStatement("UPDATE hr.employees SET LAST_NAME = ? WHERE EMPLOYEE_ID = ?");
				ps.setString(1, "König");
				ps.setLong(2, 100);
				ps.executeUpdate();
				
				
		} finally {
			if (con != null) con.close();
		}
		
		

	}

}
