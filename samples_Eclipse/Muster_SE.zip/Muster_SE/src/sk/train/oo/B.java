package sk.train.oo;

class B extends A {
	
	private String s = "Hallo";
	
	void foo() {
		System.out.println(s);
		
		
	}
	
	public static void main(String[] args) {
		new B().foo();
	}
}