Basisversion der Mitarbeiterklasse mit
- geringfügig erweiterten Enum für das Geschlecht
- statischen Zähler für die Personalnummer
- überschriebenen Standardmethoden (toString, equals, hashcode)
- angedeutetem JUnit-Test statt main-Methode