package sk.train;

public enum Gender { W, M, D }
