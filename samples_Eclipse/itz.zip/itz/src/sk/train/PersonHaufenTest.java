package sk.train;

public class PersonHaufenTest {

	public static void main(String[] args) {

		PersonHaufen ph = new PersonHaufen();
		
		System.out.println(ph);

	}

}
