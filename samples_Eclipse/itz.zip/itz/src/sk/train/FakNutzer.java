package sk.train;

public class FakNutzer {

	public static void main(String[] args) {
		//Fakuktaet f = new Fakuktaet();

	}

}
