package sk.train.mitarbeiter;

public class MitarbeiterVewrwaltung {

	
	  //Array für 100 Mitarbeiter
	
	  // befüllen
	
	  //toString()
	
	  //getGehaltssumme()
}
