Basisversion der Mitarbeiterklasse und sauberer Vererbung,
aber leider ist getGehalt auf der Strecke geblieben. 
Ergänzt um die Basisversion der Mitarbeiterverwaltung.