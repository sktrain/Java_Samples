package sk.train.ma_basic_dep;

public enum Geschlecht { W, M, D }
