Basisversion der Mitarbeiterklasse, erweitert um eine Abteilungsklasse 
und ein Enum für das Geschlecht