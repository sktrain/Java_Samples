package sk.train.mitarbeiter_database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {
	
	private Connection myconnect;
	
	public Connection createConnection() throws ClassNotFoundException, SQLException{
		Class.forName("oracle.jdbc.OracleDriver");
		myconnect = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
		return myconnect;
		
	}
	
	public void closeConnection() throws SQLException{
		myconnect.close();
	}

}
