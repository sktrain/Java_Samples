Basisversion der Mitarbeiterklasse, mit unsauberer Vererbung.
Alternative skizziert mit Arbeiter_HasA.
Ergänzt um DB-Zugriff und GUI mit JTable.