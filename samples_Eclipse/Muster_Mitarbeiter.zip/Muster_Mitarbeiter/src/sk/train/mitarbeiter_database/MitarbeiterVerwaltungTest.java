package sk.train.mitarbeiter_database;

public class MitarbeiterVerwaltungTest {

	public static void main(String[] args) {

		MitarbeiterVerwaltung mv = new MitarbeiterVerwaltung();
		
		//Gehaltssumme berechnen und ausgeben
		
		int gehaltssumme = mv.getGehaltsSumme();
		
		System.out.println("Gehaltssumme: " + gehaltssumme);
		
		//Liste der Mitarbeiter ausgeben
		
		System.out.println(mv);

	}

}
