package sk.train.mitarbeiter_database;


public class Arbeiter extends Mitarbeiter{
	
	private int stdlohn;
	private int stdzahl;	
	
	
	public Arbeiter(int persnr, String name, int stdlohn, int stdzahl) {
		super(persnr, name, stdlohn*stdzahl);
		this.stdlohn = stdlohn;
		this.stdzahl = stdzahl;
	}

	public int getStdlohn() {
		return stdlohn;
	}

	public void setStdlohn(int stdlohn) {
		super.setGehalt(stdlohn*stdzahl);
		this.stdlohn = stdlohn;
	}

	public int getStdzahl() {
		return stdzahl;
	}

	public void setStdzahl(int stdzahl) {
		super.setGehalt(stdlohn*stdzahl);
		this.stdzahl = stdzahl;
	}

	@Override
	public String toString() {
		return "Arbeiter [stdlohn=" + stdlohn + ", stdzahl=" + stdzahl + ", "
				+ "getName()=" + getName() + ", getGehalt()="
				+ getGehalt() + ", getPersnr()=" + getPersnr() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + stdlohn;
		result = prime * result + stdzahl;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Arbeiter other = (Arbeiter) obj;
		if (stdlohn != other.stdlohn)
			return false;
		if (stdzahl != other.stdzahl)
			return false;
		return true;
	}	

}
