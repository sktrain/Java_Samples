package sk.train.ma_verwaltung_abstract;

public enum Geschlecht { W, M, D

}
