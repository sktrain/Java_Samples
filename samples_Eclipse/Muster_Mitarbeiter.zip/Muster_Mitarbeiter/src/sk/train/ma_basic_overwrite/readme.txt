Basisversion der Mitarbeiterklasse mit überschriebenen Standardmethoden 
(toString, equals, hashcode)