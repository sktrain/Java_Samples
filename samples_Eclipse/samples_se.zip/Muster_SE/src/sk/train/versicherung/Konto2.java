/* Klasse zur Modellierung eines Versicherungskontos 
 * Verwendet BigDecimal f�r Rentenbetrag und GregorianCalendar f�r Geburtsdatum 
 * und innere Klasse f�r Adresse
 */

package sk.train.versicherung;
import java.math.BigDecimal;
import java.util.Calendar;

/* Klasse zur Modellierung eines Versicherungskontos */
/* Verwendet BigDecimal f�r Rentenbetrag und GregorianCalendar f�r Geburtsdatum */

public class Konto2 {
	/* Datenattribute */
	private int nummer;
	private String name;
	private Calendar geburtsdatum;  //Geburtsdatum auf Basis Calendar, alternativ direkte Verwendung von GregorianCalendar
	private int alter; //in Jahren
	private BigDecimal monatsrente;  //umgestellt auf BigDecimal
	private Adresse adresse;
	
	/* Adresse als innere Klasse */
	private class Adresse{
		private String strasse;
		private String ort;
		/**
		 * @return the strasse
		 */
		public String getStrasse() {
			return strasse;
		}
		/**
		 * @param strasse the strasse to set
		 */
		public void setStrasse(String strasse) {
			this.strasse = strasse;
		}
		/**
		 * @return the ort
		 */
		public String getOrt() {
			return ort;
		}
		/**
		 * @param ort the ort to set
		 */
		public void setOrt(String ort) {
			this.ort = ort;
		}
		
	}
	
	/* Konstruktoren */
	//Konstruktor setzt das Geburtsdatum, Alter in Jahren wird berechnet, 
	//wirft Exception bei Geburtsdatum in der Zukunft
	public Konto2(int nummer, String name, Calendar geburtsdatum, BigDecimal monatsrente)
		throws Exception
	{
		this.nummer = nummer; 	//akzeptiert jede Ganzzahl
		this.name = name;     	//akzeptiert jeden String
		//kein Geburtsdatum in der Zukunft
		Calendar aktuell = Calendar.getInstance(); //getInstance erzeugt Zeitstempel auf Basis des aktuellen Systemzeit
		if (geburtsdatum.after(aktuell)){   
			Exception e = new Exception("Fehler beim Aufruf des Konstruktors: Geburtdatum kann nicht in Zukunft liegen");
			throw e;  //sch�ner w�re das Ableiten und Anpassen einer eigenen Exception-Klasse
		} else{
			this.geburtsdatum = geburtsdatum;
			//Berechnung des Alters in Jahren
			alter = aktuell.get(Calendar.YEAR) - geburtsdatum.get(Calendar.YEAR);
		}
		if (monatsrente.compareTo(BigDecimal.ZERO) > 0) {	//setzt negative Monatsrenten auf 0
			this.monatsrente = monatsrente; 
		} else{
			this.monatsrente = BigDecimal.ZERO;
		}
	}
	
	/* Konstruktor, der auch die Adresse erwartet und inneres Objekt instantiiert */
	/* falls der andere Konstruktor verwendet wird, ist die Adresse nicht gesetzt */
	public Konto2(int nummer, String name, Calendar geburtsdatum, BigDecimal monatsrente, String ort, String strasse)
	throws Exception {
		this(nummer, name, geburtsdatum, monatsrente);
		adresse = new Adresse();
		adresse.setOrt(ort);
		adresse.setStrasse(strasse);
	}
	
	/* Methoden */
	public int getNummer() {
		return nummer;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAlter() {
		return alter;
	}
	
	public Calendar getGeburtsdatum() {
		return geburtsdatum;
	}

	public void setGeburtsdatum(Calendar geburtsdatum) throws Exception {
		Calendar aktuell = Calendar.getInstance(); //getInstance erzeugt Zeitstempel auf Basis des aktuellen Systemzeit
		if (geburtsdatum.before(aktuell)){   
			Exception e = new Exception("Fehler beim Aufruf: Geburtdatum kann nicht in Zukunft liegen");
			throw e;
		} else{
			this.geburtsdatum = geburtsdatum;
			//Berechnung des Alters in Jahren
			alter = aktuell.get(Calendar.YEAR) - geburtsdatum.get(Calendar.YEAR);
		}
	}

	public BigDecimal getMonatsrente() {
		return monatsrente;
	}

	public void setMonatsrente(BigDecimal monatsrente) {
		if (monatsrente.compareTo(BigDecimal.ZERO) > 0) {	//setzt negative Monatsrenten auf 0
			this.monatsrente = monatsrente; 
		} else{
			this.monatsrente = BigDecimal.ZERO;
		}
	}
	
	public BigDecimal getJahresrente(){		//berechnet die j�hrliche Rente
		return (monatsrente.multiply(new BigDecimal(12)));
	}
	
	@Override
	public String toString(){		//angepasste (�berschriebene) toString-Methode
		return (nummer + ": " + name);
	}
	
	/* spezielle String-Darstellung unter Nutzung der inneren Instanz, liefert auch die Adresse*/
	public String toStringWithAdress(){
		if (adresse == null) {
			return this.toString(); }
			else {
				return (this.toString()+": "+adresse.getOrt()+": "+adresse.getStrasse());
			}
		}
	
	
	@Override
	public boolean equals(Object other){	//angepasste (�berschriebene) equals-Methode
		if (other instanceof Konto2){  //dadurch sicher, dass other vom Typ Konto2
			Konto2 o = (Konto2)other; //Cast um den Compiler ruhig zu stellen
			if (nummer == o.nummer & name.equals(o.name) & geburtsdatum.equals(o.geburtsdatum) 
					& monatsrente.equals(o.monatsrente)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	
	/* Ende der Klasse */
}
