package sk.train.ma_basic_overwrite_dep_abstract;

import java.math.BigDecimal;
import java.time.LocalDate;

public class MitarbeiterTest {

	public static void main(String[] args) {

		Arbeiter a1 = new Arbeiter(4711, "Max", "Maulwurf", LocalDate.of(1960, 1, 1), LocalDate.of(2014, 1, 1), 
				new BigDecimal(17.25), new BigDecimal(100));

		System.out.println(a1.getGehalt());

		System.out.println(a1);

		FixGehaltMitarbeiter m1 = new FixGehaltMitarbeiter( 1,"Max", "Mustermann", LocalDate.of(1969,8, 14),
                LocalDate.of(2015, 1, 1), Geschlecht.M, new BigDecimal(5000) );
		
		System.out.println(m1);


	}

}
