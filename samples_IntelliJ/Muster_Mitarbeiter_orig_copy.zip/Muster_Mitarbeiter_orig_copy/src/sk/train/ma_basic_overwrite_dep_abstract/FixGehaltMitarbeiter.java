package sk.train.ma_basic_overwrite_dep_abstract;

import java.math.BigDecimal;
import java.time.LocalDate;

public class FixGehaltMitarbeiter extends Mitarbeiter {
	
	private BigDecimal gehalt;
	
	public FixGehaltMitarbeiter(int persnr, String vorname, String nachname, LocalDate gebdatum, LocalDate einstdatum,
			BigDecimal gehalt) {
		super(persnr, vorname, nachname, gebdatum, einstdatum);
		this.gehalt = gehalt;
	}	

	public FixGehaltMitarbeiter(int persnr, String vorname, String nachname, LocalDate gebdatum, LocalDate einstdatum,
			Geschlecht ges, BigDecimal gehalt) {
		super(persnr, vorname, nachname, gebdatum, einstdatum, ges);
		this.gehalt = gehalt;
	}

	public FixGehaltMitarbeiter(int persnr, String vorname, String nachname, LocalDate gebdatum, LocalDate einstdatum,
			Abteilung abt, Geschlecht ges, BigDecimal gehalt) {
		super(persnr, vorname, nachname, gebdatum, einstdatum, abt, ges);
		this.gehalt = gehalt;
	}


	public BigDecimal getGehalt() {
		return gehalt;
	}

	public void setGehalt(BigDecimal gehalt) {
		this.gehalt = gehalt;
	}
	
	
	//geerbte Standardmethoden sind ok!
}
