package sk.train.ma.strategy.verwaltung_strategy_gui;

public enum Geschlecht { W, M, D

}
