package sk.train.ma.strategy.verwaltung_strategy;

public enum Geschlecht { W, M, D

}
