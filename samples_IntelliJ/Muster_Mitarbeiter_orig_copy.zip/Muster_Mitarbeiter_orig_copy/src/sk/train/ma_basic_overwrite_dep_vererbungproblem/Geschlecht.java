package sk.train.ma_basic_overwrite_dep_vererbungproblem;

public enum Geschlecht {
	W, M, D;

	static Geschlecht getDefault() {
		return D;
	}

	@Override
	public String toString() {
		switch (name()) {
		case "W": return "weiblich";
		case "M": return "m�nnlich";
		default:  return "divers";
		}
	}

}
