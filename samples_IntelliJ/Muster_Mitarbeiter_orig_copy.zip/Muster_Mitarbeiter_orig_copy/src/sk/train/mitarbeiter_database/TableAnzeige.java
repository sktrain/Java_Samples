package sk.train.mitarbeiter_database;

import java.sql.Connection;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableModel;

public class TableAnzeige {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		//DB-Verbindung beschaffen
		Connection c = new DBConnect().createConnection();

		//Model instantiieren
		TableModel model = new MAV(c);
		
		//JTable mit Model f�ttern
		JTable mytable = new JTable(model);
		
		JScrollPane sp = new JScrollPane(mytable);
		
		JFrame myframe = new JFrame();
		
		myframe.add(sp);
		
		myframe.pack();
		
		myframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		myframe.setVisible(true);

	}

}
