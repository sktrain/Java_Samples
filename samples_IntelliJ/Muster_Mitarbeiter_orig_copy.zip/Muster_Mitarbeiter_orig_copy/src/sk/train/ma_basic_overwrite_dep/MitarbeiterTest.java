package sk.train.ma_basic_overwrite_dep;

import java.math.BigDecimal;
import java.time.LocalDate;

public class MitarbeiterTest {

	public static void main(String[] args) {

      Mitarbeiter m1 = new Mitarbeiter( 1,"Max", "Mustermann", LocalDate.of(1969,8, 14),
    		                LocalDate.of(2015, 1, 1), new BigDecimal(5000));
      
      System.out.println(m1);
      
      Mitarbeiter praktikant = new Mitarbeiter(500, "Otto", "Student", LocalDate.of(2000, 5, 11),
              LocalDate.of(2022, 1, 1));
      
      System.out.println(praktikant);
      
      Mitarbeiter abtleiter = new Mitarbeiter(2, "Erika", "Abteilungsleiter", LocalDate.of(1970, 1, 25),
              LocalDate.of(2015, 1, 1), new BigDecimal(8000), Geschlecht.W);
      
      System.out.println(abtleiter);
      
      Abteilung abt = new Abteilung(abtleiter, "Testabteilung","IT");
      
      System.out.println(abt);
      
      abtleiter.setAbt(abt); 
      
      m1.setAbt(abt);
      
      System.out.println(m1);
      
      abt.setAbtleiter(abtleiter);
      
      System.out.println(abt);
      

	}

}







