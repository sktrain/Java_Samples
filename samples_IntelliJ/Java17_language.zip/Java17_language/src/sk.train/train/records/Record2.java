package sk.train.train.records;

public record Record2(int x, Record1 r) {

}
