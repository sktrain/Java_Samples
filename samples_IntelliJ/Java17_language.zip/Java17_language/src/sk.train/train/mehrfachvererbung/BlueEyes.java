package sk.train.train.mehrfachvererbung;

public interface BlueEyes {	
	default String getColor() {
		return "blue";
	}
}
