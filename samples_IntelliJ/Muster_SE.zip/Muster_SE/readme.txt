Samples zur Java SE als Eclipse-Projekt
+  H2-Database Treiber (momentan nur für H2, nicht für andere DBMS)
im dependencies-Ordner
