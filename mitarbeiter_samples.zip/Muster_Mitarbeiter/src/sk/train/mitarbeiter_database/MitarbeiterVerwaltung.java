package sk.train.mitarbeiter_database;

import java.util.Arrays;

public class MitarbeiterVerwaltung {
	
	//Liste von Mitarbeitern
	private Mitarbeiter[] mitarbeiterliste;
	
	//Konstruktor
	public MitarbeiterVerwaltung() {
		super();
		// Array instantiieren
		
		mitarbeiterliste = new Mitarbeiter[100];
		
		//F�llschleife um das Array mit Mitarbeitern zu f�llen: H�lfte Arbeiter, h�lfte Fixgehalt
		
		for (int i = 0; i < mitarbeiterliste.length; ++i) {
			if (i%2 == 0) {
				mitarbeiterliste[i] = new Arbeiter(i, "Maulwurf"+i,(int) (Math.random()*100), 100);
			}else {
				mitarbeiterliste[i] = new Mitarbeiter(i, "Musterfrau"+i,(int) (Math.random()*10000));
			}
		}
		
	}
	
	//Summe der Geh�ltern sollte lieferbar sein
	public int getGehaltsSumme() {
		//Gehaltssumme berechnen und zur�ckliefern
		int result = 0;
		for (Mitarbeiter m : mitarbeiterliste) {
			result = result + m.getGehalt();
		}
		return result;
	}

	

//	Die Utility-Methode Arrays.toString macht leider keine Zeilenumbr�che, 
//	wird aber beim Generieren von Eclipse benutzt
//	@Override
//	public String toString() {
//		return "MitarbeiterVerwaltung [mitarbeiterliste=" + Arrays.toString(mitarbeiterliste) + "]";
//	}
	
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		for (Mitarbeiter m : mitarbeiterliste) {
			sb.append(m.toString() + "\n");
		}
		return sb.toString();
	}
	
	

}
