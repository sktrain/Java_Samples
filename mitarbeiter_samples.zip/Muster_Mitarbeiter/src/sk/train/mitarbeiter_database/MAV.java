package sk.train.mitarbeiter_database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

import org.omg.CORBA.portable.ApplicationException;

public class MAV extends AbstractTableModel{
	 final public static int ARRAYSIZE = 100;

	 private Mitarbeiter[] marray  = new Mitarbeiter[ARRAYSIZE];
	 private Connection myconnect;
	
	 public MAV(Connection myconnect) throws SQLException{  // jetzt Testdaten, zuk�nftig DBMS
			// Datenbankabfrage
			//Mitarbeiterobjekte aufbauen
		    this.myconnect = myconnect;
		    Statement st = myconnect.createStatement();
			String query = "SELECT employee_id, last_name, salary from employees where rownum < " + (ARRAYSIZE+1);
			ResultSet rs = st.executeQuery(query);
			//int  anzahlspalten = rs.getMetaData().getColumnCount();
			//System.out.println("Insgesamt Spalten verf�gbar: " + anzahlspalten);
			int i = 0;
			while (rs.next()){				
				Mitarbeiter m = null;
				m = new Mitarbeiter(rs.getInt("employee_id"), rs.getString("last_name"), rs.getBigDecimal("salary").intValue());
				marray[i] = m;
				++i;
			}
			 
					
	 }
		
	public int getGehaltsumme(){
		int gehaltssumme = 0;
			
		for(Mitarbeiter x : marray){
			gehaltssumme = gehaltssumme + x.getGehalt();
		}
		return gehaltssumme;		
	}

	public Mitarbeiter[] getMarray() {
		return marray;
	}

	@Override
	public String toString() {
		StringBuffer s = new StringBuffer("");
		for (Mitarbeiter m : marray){
			s = s.append(m.toString()).append("\n");
		}
		return "MAV [marray="  + s +"]";
	}

	@Override
	public int getColumnCount() {
		
		return 3;
	}

	@Override
	public int getRowCount() {
		
		return 100;
	}

	@Override
	public Object getValueAt(int arg0, int arg1) {
		if (arg1 == 0){
			return marray[arg0].getPersnr();
		}
		if (arg1 == 1){
			return marray[arg0].getName();
		}
		if (arg1 == 2){
			return marray[arg0].getGehalt();
		}
		return null;
	}	

	

}
