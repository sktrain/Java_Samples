Basisversion der Mitarbeiterklasse und sauberer Vererbung,
aber leider ist getGehalt auf der Strecke geblieben. 
Erg�nzt um die Basisversion der Mitarbeiterverwaltung.