package sk.train;

import java.util.Date;

public class CastTest {

	public static void main(String[] args) {

			String s = "Hallo";
			
			Date d = new Date();
			
			//d = s;
			
			Object o = d;		
			
			System.out.println(o.toString());
			
			if (o.getClass() == String.class) { System.out.println(((String)o).length()); }
			
			if (o instanceof String) System.out.println(((String)o).length());


	}

}
