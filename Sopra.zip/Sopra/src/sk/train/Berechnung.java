package sk.train;

import java.math.BigInteger;

public class Berechnung {
	
	private Berechnung() {
		
	}

	public static void main(String... args) {
		    for (int i = 0; i < args.length; i++) {
		    	System.out.println(args[i]);
		    }
		//System.out.println(fakultaetBig(new BigInteger("50")));
		for (int i = 1; i < 100; i++) {
			int erg = new  Berechnung().fakultaet(i);
			System.out.println("Fakultaet von " + i + " ist: " + erg);
			erg = fakultaetWhile(i);
			System.out.println("Fakultaet von " + i + " ist: " + erg);
			erg = fakultaetRek(i);
			System.out.println("Fakultaet von " + i + " ist: " + erg);
			//todo: BigInteger-Fakultaetsvariante
			BigInteger ergb = fakultaetBig(new BigInteger(i+""));
			System.out.println("Fakultaet von " + i + " ist: " + ergb);
		}
	}	
	
	public static BigInteger fakultaetBig(BigInteger n) {
		BigInteger erg = BigInteger.ONE; //new BigInteger("1");
		for(BigInteger i = BigInteger.ONE;  /*i.compareTo(n) <= 0 */; i = i.add(BigInteger.ONE)) {
			if (i.compareTo(n) > 0) {break;}
			erg = erg.multiply(i);
		}
		return erg;
	}
	
	public  static int fakultaet(int n) {
		if (n < 1) {
			throw new IllegalArgumentException("hier nur positive Ganzzahl erlaubt");
		}
		int erg = 1;
		for ( int i = 1; i <=n; i=i+1) {
			erg = erg * i;    //Math.multiplyExact(erg , i);
		}		
		return erg;
	}
	
	public static int fakultaetWhile(int n) {
		int erg = 1; int i = 1;
		while (i <= n) {
			erg = erg * i;
			i = i+1;
		}
		return erg;
	}
	
	public static int fakultaetRek(int n) {
		if (n == 1) return 1;
		else return n * fakultaetRek(--n);
	}
	
	public static int gaussSumme(int n) {
		int ergebnis = n * (n+1)/2;
		return ergebnis;
	}
	
	

}
