package sk.train;

public class Kind1 extends Eltern {
	
	private int k;
	private String t;	

	public Kind1(int i, String s, int k, String s2) {
		super(i, s);
		this.k = k;
		t = s2;
	}

	public int getK() {
		return k;
	}

	public void setK(int k) {
		this.k = k;
	}

	@Override
	public String getS() {
		return t;
	}

	public void setS(String s) {
		this.t = s;
	}
	
	public int berechne(int n) {
		return k +n;
	}
	
	
	public boolean equals(Kind k) {
		return true;
	}
	
	@Override
	public boolean equals(Object o) {
		return false;
	}
	
	

}
