package sk.train;

public class Eltern {
	
	private int i;
	private String s;
	
	public Eltern(int i, String s) {
		super();
		this.i = i;
		this.s = s;
	}

	public String getS() {
		return s;
	}

	public void setS(String s) {
		this.s = s;
	}
	
	
	
	

}
