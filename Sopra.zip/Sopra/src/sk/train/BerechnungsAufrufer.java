package sk.train;

public class BerechnungsAufrufer {

	public static void main(String[] args) {

				int erg = Berechnung.fakultaet(5);
				System.out.println(erg);
				
				//String[] params = {"huhu", "Hallo", "otto"};
				Berechnung.main("huhu", "Hallo", "otto");

	}

}
