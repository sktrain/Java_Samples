package sk.train;

public enum Geschlecht2 {

}
