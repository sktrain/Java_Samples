package sk.train;

public class KreisTest {

	public static void main(String[] args) {

		Kreis k1;
		
		k1 = new Kreis(0, 0, 1);
		
		double u = k1.getumfang();
		
		double f = k1.getflaeche();
			
	
		
		System.out.println(u);
		System.out.println(f);
		System.out.println(k1);
		
		

	}

}
