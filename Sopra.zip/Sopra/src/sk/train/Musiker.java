package sk.train;

public class Musiker {
	
	private Instrument i;
	
	public Musiker(Instrument i) {
		this.i = i;
	}
	
	public void perform() {
		i.play();
	}
	
	public static void main(String[] args) {
		Musiker m1 = new Musiker(new Gitarre());
		m1.perform();
		
		Musiker m2 = new Musiker(new Klavier());
		m2.perform();
	}
}

interface Instrument{
	public abstract void play();
}

class Gitarre implements Instrument {
	public void play() {
		System.out.println("Gitarrenkl�nge");
	}
}

class Klavier implements Instrument{

	@Override
	public void play() {
		System.out.println("Klavierkl�nge");
		
	}
	
}
