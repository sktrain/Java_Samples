// Service provider framework sketch - Service provider interface - Page 12
package sk.train;
public interface Provider {
    Service newService();
}