package sk.train;

public class BerechnungsTest {

	public static void main(String[] args) {
//		 Berechnung b = new Berechnung();
//		 System.out.println(b);
		System.out.println(Berechnung.fakultaet(5));

	}

}
