package sk.train;

import java.util.Date;

public class Kind extends Person{
	
	private boolean kindergartenkind;
	private String spielzeug;
	
	
	
//	private Kind(boolean kindergartenkind, String spielzeug) {
//		
//		this.kindergartenkind = kindergartenkind;
//		this.spielzeug = spielzeug;
//	}
	
	public Kind(String vorname, String nachname, Date gebdatum, int alter, boolean kindergartenkind,
			String spielzeug) {
		super(vorname, nachname, gebdatum, alter);
		this.kindergartenkind = kindergartenkind;
		this.spielzeug = spielzeug;
	}
	public boolean isKindergartenkind() {
		return kindergartenkind;
	}
	public void setKindergartenkind(boolean kindergartenkind) {
		this.kindergartenkind = kindergartenkind;
	}
	public String getSpielzeug() {
		return spielzeug;
	}
	public void setSpielzeug(String spielzeug) {
		this.spielzeug = spielzeug;
	}
	@Override
	public String toString() {
		return "Kind [kindergartenkind=" + kindergartenkind + ", spielzeug=" + spielzeug + ", getVorname()="
				+ getVorname() + ", getNachname()=" + getNachname() + ", getGebdatum()=" + getGebdatum()
				+ ", getAlter()=" + getAlter() + "]";
	}
	
}
