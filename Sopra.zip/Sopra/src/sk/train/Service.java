// Service provider framework sketch - Service interface - Page 12
package sk.train;
public interface Service {
    // Service-specific methods go here
}
