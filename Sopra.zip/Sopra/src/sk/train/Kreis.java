package sk.train;

public class Kreis {
	
	//Datenattribute
	private double x;
	private double y;
	private double r;
	
	
	//Bildungsvorschrift: Konstruktor
	public Kreis(double x_kord, double y_kord, double radius) {
		x = x_kord;
		y = y_kord;
		r = radius;
	}
	
	public double getumfang() {
		return 2 * r * Math.PI;
	}
	
	public double getflaeche() {
		return r * r * Math.PI;
	}

}
