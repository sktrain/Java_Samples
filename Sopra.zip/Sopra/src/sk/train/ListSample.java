package sk.train;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

import sk.train.mav.FixgehaltMitarbeiter;
import sk.train.mav.Geschlecht;
import sk.train.mav.Mitarbeiter;

public class ListSample {

	public static void main(String[] args) {

			ArrayList<Mitarbeiter> maliste = new ArrayList<>();
			
			for (int i = 0; i < 100; i++) {
				Mitarbeiter m = new FixgehaltMitarbeiter(i, "Max"+i, "Muster"+i, 
						LocalDate.of(1980, 1+new Random().nextInt(11), 1), 
						LocalDate.of(2000, 1, 1),
						Geschlecht.M,
						new BigDecimal("5000.0"));
				maliste.add(m);
			}
			
			for (Mitarbeiter l : maliste) {
				System.out.println(l);
			}


	}

}
