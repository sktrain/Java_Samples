package sk.train;

import java.util.Date;

public class PersonTest {

	public static void main(String[] args) {

			Person p;
			
			//p = new Person();
			
			p = new Person("Erika", "Musterfrau", new Date(110, 0,1), 10 );
			
			System.out.println(p.getNachname());
			System.out.println(p.getAlter());
			System.out.println(p.getGebdatum());
			System.out.println(p);
//			
			p.setNachname("Karrer");
//			
			System.out.println(p.getNachname());
			
			p.setAlter(-100);

	}

}
