package sk.train;

public class VarTest {
	
	static final int j = 1; static int i = 2;

	public static void main(String[] a) {

        final int j = 1; 
        System.out.println(VarTest.j); System.out.println(j);
        //VarTest.j = 2;
        System.out.println(i);
        
       int k =gaussSumme(4);
        System.out.println(gaussSumme(4));
        
        for ( int l = 1; l <= 10 ; l =l *2) {
        	System.out.println("hier schleife");
        }
        
//        for (int x=0; ;) {;
//        	
//        }
//       

	}
	
	static public int gaussSumme(int n) {
		return (n+1)*n /2;
	}

}
