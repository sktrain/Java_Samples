package sk.train.mav;

public enum Geschlecht {M, W, D }
