package sk.train.mav;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Writer;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

import javax.swing.table.AbstractTableModel;

public class Mitarbeiterverwaltung extends AbstractTableModel {
	
	private Mitarbeiter[] maarray;
	private ArrayList<Mitarbeiter> malist;
	
	public Mitarbeiterverwaltung() {
		// Liste und/oder Array initialisieren
		malist = new ArrayList<>();
		maarray = new Mitarbeiter[100];
		
		//Schleife 100 MA erzeugen , 50:50 Arbeiter:Fixgehalt
		//und Collection f�llen
		for (int i = 0; i <100; ++i) {
			if (i%2 == 0) {
				Mitarbeiter m = new FixgehaltMitarbeiter(i, "Erika", "Musterfrau"+i, 
						                                 LocalDate.of(1950+i, 1+new Random().nextInt(11), 1)
						                                 , LocalDate.of(2000, 1, 1), 
						                                 Geschlecht.W, 
						                                 new BigDecimal(new Random().nextInt(10000)));
				System.out.println(m);
				malist.add(m);
				maarray[i] = m;						
			} else {
				Mitarbeiter a = new Arbeiter(i, "Max", "Maulwurf"+i, 
                        LocalDate.of(1950+i, 1+new Random().nextInt(11), 1)
                        , LocalDate.of(2000, 1, 1), 
                        Geschlecht.W, 
                        new BigDecimal(100),
                        new BigDecimal(1+new Random().nextInt(100)));
				malist.add(a);
				maarray[i] = a;	
				
			}
		}
	}

	public Mitarbeiter[] getMaarray() {
		return maarray;
	}

	public ArrayList<Mitarbeiter> getMalist() {
		return malist;
	}
	
	public BigDecimal getGehaltsSumme() {
		BigDecimal erg = BigDecimal.ZERO;
		for (Mitarbeiter m : malist) {
			erg = erg.add(m.getGehalt());
		}
		return erg;
	}
	
	public void writeToFile(String filename) {
		try (Writer out = new FileWriter(filename)){
			for (Mitarbeiter m : malist) {
				out.write(m.toString());
				out.write(System.lineSeparator());
			}			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void store(String filename) {
		try ( OutputStream fos = new FileOutputStream( filename) ;
			      ObjectOutputStream oos = new ObjectOutputStream( fos ) ) 
		{
			    oos.writeObject(malist);
			}
			catch ( IOException e ) {
			  System.err.println( e );
			}
	}
	
	public void load(String filename) {
		ArrayList<Mitarbeiter> malist_erg = null;		
		
		try ( ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))){
		  malist_erg = (ArrayList<Mitarbeiter>) ois.readObject();
			
		} catch (ClassNotFoundException  e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		for (Mitarbeiter m : malist_erg) {
			System.out.println(m);
		}
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 7;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return 100;
	}

//	private int persnr = 1;
//	private String vorname;
//	private String nachname = "Muster";
//	private LocalDate gebdatum = LocalDate.of(2000, 1, 1);
//	private LocalDate einstdatum;
//	private Geschlecht g = Geschlecht.D;
	
	@Override
	public Object getValueAt(int row, int column) {
		if (column == 0) return malist.get(row).getPersnr();
		if (column == 1) return malist.get(row).getVorname();
		if (column == 2) return malist.get(row).getNachname();
		if (column == 3) return malist.get(row).getGebdatum();
		if (column == 4) return malist.get(row).getEinstdatum();
		if (column == 5) return malist.get(row).getG();
		if (column == 6) return malist.get(row).getGehalt();
		return null;		
	}

	@Override
	public String getColumnName(int column) {
		if (column == 0) return "PersNr.";
		if (column == 1) return "Vorname";
		if (column == 2) return "Nachname";
		if (column == 3) return "Gebdatum";
		if (column == 4) return "Einstdatum";
		if (column == 5) return "Geschlecht";
		if (column == 6) return "Gehalt";
		return null;	
		
	}

	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		if (columnIndex == 2) return true;
		return false;
	}

	@Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
		if (columnIndex == 2) {
			malist.get(rowIndex).setNachname((String)aValue);
		}
		System.err.println(malist.get(rowIndex));		
	}
	
	
	
	
	

}
