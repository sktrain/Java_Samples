package sk.train.mav;

import java.util.Arrays;
import java.util.Collections;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class MitarbeiterVerwaltungsTest {
	
	public static void main(String[] args) {
		
		Mitarbeiterverwaltung mv = new Mitarbeiterverwaltung();
		
		mv.writeToFile("maliste.txt");
		
		mv.store("malistebinaer.ser");
		
		System.out.println("\n*****************************************************\n");
		
		mv.load("malistebinaer.ser");
		
		JScrollPane mypane =new JScrollPane( new JTable(mv));
		JFrame myframe = new JFrame("MitarbeiterListe");
		myframe.add(mypane);
		
		myframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myframe.pack();
		myframe.setVisible(true);
		
//		for (Mitarbeiter m : mv.getMalist()) {
//			System.out.println(m);
//		}
//		
//		System.out.println("\n*********************************************\n");
//		
//		for (Mitarbeiter m : mv.getMaarray()) {
//			System.out.println(m);
//		}
//		
//		System.out.println("\n*********************************************\n");
//		
//		System.out.println(mv.getGehaltsSumme());
//		
//		Arrays.sort(mv.getMaarray());
//		
//		for (Mitarbeiter m : mv.getMaarray()) {
//			System.out.println(m);
//		}
//		
//		Collections.sort(mv.getMalist());
		
		
	}

}
