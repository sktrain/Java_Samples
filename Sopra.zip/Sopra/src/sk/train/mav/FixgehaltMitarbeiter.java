package sk.train.mav;

import java.math.BigDecimal;
import java.time.LocalDate;

public class FixgehaltMitarbeiter extends Mitarbeiter{
	
	private BigDecimal gehalt;

	public FixgehaltMitarbeiter(int persnr, String vorname, String nachname, LocalDate gebdatum, LocalDate einstdatum,
			Geschlecht g, BigDecimal gehalt) {
		super(persnr, vorname, nachname, gebdatum, einstdatum, g);
		this.gehalt = gehalt;
	}

	public BigDecimal getGehalt() {
		return gehalt;
	}

	public void setGehalt(BigDecimal gehalt) {
		this.gehalt = gehalt;
	}
	
	

}
