package sk.train.mav;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Random;

public class MitarbeiterTest {

	public static void main(String[] args) {
		Mitarbeiter m = new FixgehaltMitarbeiter(1, "Erika", "Musterfrau"+1, 
                LocalDate.of(1950+1, 1+new Random().nextInt(11), 1)
                , LocalDate.of(2000, 1, 1), 
                Geschlecht.W, 
                new BigDecimal(new Random().nextInt(10000)));
		
		try {
			m.setNachname("");
		} catch (KarrersException e) {
			System.err.println("Dies war nix: " + e.getMessage());
		} catch (Exception e) {
			System.err.println("Das war ein anderer Fehler");
		}
		
		System.out.println("Hier gehts weiter");

	}

}
