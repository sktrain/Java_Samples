package sk.train.mav;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.Scanner;

public class ConsoleEinlesen {

	public static void main(String[] args)  {
		
		Date dinput = null;		
		Date d = null;
		
		try ( OutputStream fos = new FileOutputStream( "name_date.ser" ) ;
			      ObjectOutputStream oos = new ObjectOutputStream( fos ) ) 
		{
			  dinput = new Date();
			  oos.writeObject( "Chris" );
			  oos.writeObject( dinput );
			}
			catch ( IOException e ) {
			  System.err.println( e );
			}
		
		try ( ObjectInputStream ois = new ObjectInputStream(new FileInputStream("name_date.ser"))){
			String s = (String) ois.readObject();
			 d = (Date) ois.readObject();
		} catch (ClassNotFoundException  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(d == dinput);
		System.out.println(d.equals(dinput));

//		try (Writer out = Files.newBufferedWriter(Paths.get("out.bak.txt"), 
//				StandardCharsets.ISO_8859_1)) 
		
//		Writer out = Files.newBufferedWriter(Paths.get("out.bak.txt"), 
//				StandardCharsets.ISO_8859_1);
//		try (Writer out = new FileWriter("ausgabe.txt")){
//			out.write("Zwei J�ger treffen sich ...");
//			out.write(System.lineSeparator());
//			
//		} catch (IOException e) {
//			e.printStackTrace();
//		}

//			System.out.println("Jetzt bitte Eingabe");
//			
////			String s =new BufferedReader(new InputStreamReader(System.in)).readLine();
////			
////			System.out.println(s);
//			
//			Scanner s = new Scanner(System.in);
//			while(s.hasNext()) {
//				System.out.println(s.next());
//			}

	}

}
