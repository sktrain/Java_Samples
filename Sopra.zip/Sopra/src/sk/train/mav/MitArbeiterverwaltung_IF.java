package sk.train.mav;

import java.math.BigDecimal;

public interface MitArbeiterverwaltung_IF {

	BigDecimal getGehaltsSumme();

}