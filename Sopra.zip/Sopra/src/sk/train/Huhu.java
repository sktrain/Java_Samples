/* Dies uns erstes Java-Programm
 * 
 */

package sk.train;


import java.math.BigInteger;
import java.util.Date;

public class Huhu {

	public static void main(String[] args) {
		System.out.println(new Date()); // Kommentar bis Zeilende
		
		int i = 1; int j = 0;
		
		if (i > 0 || i/j > 0) {
			System.out.println("Hier Then-Zweig)");
		}
		
		System.out.println(010);
		System.out.println(0x10);
		System.out.println(0b1111_00000);
		
		System.out.println(100_000 * 100_000 / 100_000);
		
		//int erg = Math.multiplyExact(100_000_, 100_000);
		
		BigInteger b = new BigInteger("100000000");
		// b * b / b
		
		System.out.println(b.multiply(b).divide(b));
		
//		i = i+1;
//		i += 1;
//		++i;
//		j = i;
//		j = ++i;
//		System.out.println("j " + j + " : i " + i);
//		
//		double d = 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1;
//		
//		System.out.println(d);
//		
	}
}

class A {
	
}
