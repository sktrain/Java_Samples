package sk.train;

import java.applet.Applet;
import java.awt.Graphics;

public class HelloApplet extends Applet
{
    private static final long serialVersionUID = 1L;
    
    @Override
	public void paint(Graphics g)
    {
        g.drawString(generateString(),
                      25, 50);        
    }
    
    
    
    private String generateString() {
    	return "Hallo User";
    }
}