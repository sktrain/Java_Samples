package sk.train;

public class Fabrik {
	
	private String s;

	private Fabrik(String s) {
		super();
		this.s = s;
	}
	
	public static Fabrik getInstance (String s) {
		//if ....
		Fabrik f = new Fabrik(s);
		return f;
	}
	
	

}
