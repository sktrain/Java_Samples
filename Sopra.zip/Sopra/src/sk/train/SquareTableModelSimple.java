package sk.train;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;

public class SquareTableModelSimple extends AbstractTableModel {

	@Override
	public int getRowCount() {
		return 100;
	}

	@Override
	public int getColumnCount() {
		return 3;
	}

	@Override
	public String getValueAt(int row, int col) {
		if (col == 0)
			return "" + row;
		else if (col == 1)
			return "" + (row * row);
		else
			return "" + (row * row * row);
	}

	@Override
	public String getColumnName(int column) {
		if (column == 0) {return "Zahl";}
		if (column == 1) {return "Quadrat";}
		return  "3.Potenz";
	}

	public static void main(String[] args) {
		SquareTableModelSimple mymodel = new SquareTableModelSimple();
		JTable mytable = new JTable(mymodel);
		JScrollPane spane = new JScrollPane(mytable);
		JFrame myframe = new JFrame("Tabelle der Quadratzahlen");
		myframe.add(spane);

		myframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myframe.setSize(500, 500);
		myframe.setVisible(true);

	}
}