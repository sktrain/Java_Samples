package sk.train;

public class ElternKindTest {

	public static void main(String[] args) {

        Eltern e = new Eltern(1, "Eltern");
        
        Kind1 k = new Kind1(2, "Eltern von Kind", 2, "Kind");
        
        System.out.println(e.getS());
        
        System.out.println(k.getS());
        
        System.out.println(k.berechne(2));
        
//        e = k;
//        
//        System.out.println(e.getS());
//        
//        int erg = ((Kind1) e).berechne(3);
        
        System.out.println(e);

	}

}
