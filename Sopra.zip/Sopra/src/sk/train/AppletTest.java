package sk.train;

import java.awt.Graphics;

public class AppletTest {

	public static void main(String[] args) {
		HelloApplet ha = new HelloApplet();
		
		ha.paint(null);
	}

}
