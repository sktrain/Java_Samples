package sk.train;

import java.util.Date;

public class Person {
	
	//Datenattribute
	
	private String vorname = "Max";
	private String nachname = "Mustermann";
	private Date gebdatum = new Date(100,0,1);
	private int alter = 20;
	
//	public Person() {
//		//super();
//	}

	public Person(String vorname, String nachname, Date gebdatum, int alter) {
		super();
		this.vorname = vorname;
		this.nachname = nachname;
		this.gebdatum = gebdatum;
		this.alter = alter;
	}
	
	public void setAlter (int alter) {
		if (alter <= 0) {}
		else {this.alter = alter;}
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public Date getGebdatum() {
		return gebdatum;
	}

	public int getAlter() {
		return alter;
	}
	
	
	
	


	

}
