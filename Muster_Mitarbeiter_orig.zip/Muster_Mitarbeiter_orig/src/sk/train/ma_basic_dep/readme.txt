Basisversion der Mitarbeiterklasse, erweitert um eine Abteilungsklasse 
und ein Enum f�r das Geschlecht