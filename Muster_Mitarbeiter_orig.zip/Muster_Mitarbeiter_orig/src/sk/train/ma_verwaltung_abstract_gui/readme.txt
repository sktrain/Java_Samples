Basisversion der Mitarbeiterklasse, sauberer Vererbung und 
abstrakter Elternklasse f�r die abstrakte getGehalt-Methode.
Entsprechend kann die Mitarbeiterverwaltung die Gehaltssumme liefern.
Erg�nzt um Comparatoren. Erg�nzt um JTable-Gui.