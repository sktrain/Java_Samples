package sk.train.ma_verwaltung_serialisierbar;

public enum Geschlecht { W, M, D

}
