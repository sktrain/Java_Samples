package Aufgaben_Karrer_Streams.Aufgabe2;

import java.util.stream.IntStream;

// Berechnung des Produkts der positiven Ganzzahlen von 1 bis 100 (Fakultät)
// und der Summe dieser Zahlen in einem Stream-Durchlauf mittels eigenem Reducer


public class Reduce_Sum_Fak {

	public static void main(String[] args) {

		//Hinweis: da die Fakultätsberechnung schnell wächst, sollte auf BigInteger gewechselt werden
		IntStream is = IntStream.range(1, 100);
		
	}
}

