package Aufgaben_Karrer_Streams.Aufgabe1;

import java.util.stream.IntStream;

// Berechnung der Anzahl der positiven, negativen und 0-Werte in einem gegebenen Array mittels
// eines Stream-Durchlaufs.
// Hier mit selbstgeschriebenen Collector

public class PosNegCounter_MyCollector {

	public static void main(String[] args) {

		// hier kann intStream verwendet werden, da kein fertiger Collector aus Collectors verwendet wird
     	IntStream.of(1, -2, 4, 5, 7, -8, 0);
     
     	//todo
      
	}
}


