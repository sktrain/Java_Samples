package Aufgaben_Karrer_Streams.Aufgabe1;

import java.util.stream.Stream;

// Berechnung der Anzahl der positiven, negativen und 0-Werte in einem gegebenen Array mittels
// eines Stream-Durchlaufs.
// Hier mit Standard-Collector




public class PosNegCounter {

	public static void main(String[] args) {

		// da intStream nicht durch Collectors unterstützt wird: Stream<Integer>
         Stream<Integer> is = Stream.of(-1, 3, 5, 0, -4, 7, 0, 8);

		 //todo
         
         

	}

}
