Basisversion der Mitarbeiterklasse, 
- erweitert um eine Abteilungsklasse 
- mit simplem Enum für das Geschlecht
- statischen Zähler für die Personalnummer