Basisversion der Mitarbeiterklasse und sauberer Vererbung,
aber leider ist getGehalt auf der Strecke geblieben. 
- Ergänzt um eine Basisversion der Mitarbeiterverwaltung
  (gleichzeitige Verwendung einer Liste und eines Arrays nur zur Demo)