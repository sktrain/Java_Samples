package sk.train.aufgaben_Lambdas_3_3;

public class Application {

	public static void main(String[] args) {
		new MathFrame();
	}
	
}
