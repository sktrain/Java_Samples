package aufgaben_Streams_1;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;



public class Aufgabe_5_loes
{
    public static void main(final String[] args)
    {
        final List<Person> persons = new ArrayList<>();
        persons.add(new Person("Tim", 10));
        persons.add(new Person("Trude", 20));
        persons.add(new Person("Tomas", 30));
        persons.add(new Person("Max", 40));
        
        
        // a) Berechnen Sie das durchschnittliche Alter der Personen, deren Name mit einem "T" beginnt
        
        OptionalDouble averageAlter = persons.stream()
        		.filter(person -> person.getName().startsWith("T"))
        		.mapToInt(Person::getAge)
        		.average();
        
        System.out.println("Durchschnittsalter: " + averageAlter.orElse(0.0));
        
        
        // b) Gibt es Personen in der Liste, deren Name ein "u" enthält?
        
        boolean hit = persons.stream()
        		.anyMatch(person -> person.getName().contains("u"));
        System.out.println("Name enthält u: " + hit);

        
    }
}