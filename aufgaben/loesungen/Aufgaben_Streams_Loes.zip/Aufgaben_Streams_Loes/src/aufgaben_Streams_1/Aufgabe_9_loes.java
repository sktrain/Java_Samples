package aufgaben_Streams_1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class Aufgabe_9_loes
{
    public static void main(String[] args) throws IOException
    {
    	// a) Es sollen nur die Worte aus der Textdatei "Example.txt" sortiert in einer Liste gespeichert werden,
    	// deren Länge mindestens 4 ist. Die Satzzeichen (, : . ? !) sind zu eliminieren.
    	
    	
        Path exampleFile = Paths.get("src/aufgaben_Streams_1/Example.txt");

        Function<String, String> removeSpecialCharsn = str -> { return str.replaceAll("\\W", "");  };
        // \W steht für nicht Wortzeichen. Wortzeichen sind: [a-zA-Z_0-9]
        
        List<String> words = Files.lines(exampleFile)
        		.flatMap(line -> Stream.of(line.split(" ")))
        		.map(removeSpecialCharsn)
        		.filter( string -> string.length() > 3)
        		.sorted()
        		.collect(Collectors.toList());
        
        System.out.println(words);
        
        
        // b) Kann für das Ergebnis auch zielgerichtet eine ArrayList spezifiziert werden?
        
        ArrayList<String> awords = Files.lines(exampleFile)
        		.flatMap(line -> Stream.of(line.split(" ")))
        		.map(removeSpecialCharsn)
        		.filter( string -> string.length() > 3)
        		.sorted()
        		.collect(Collectors.toCollection(ArrayList::new));
        
        System.out.println(awords);
        
        
        // c) Können Sie auch mit Hilfe eines geeigneten Collectors die Worthäufigkeiten speichern?
       
        Map<String, Long> wordcount = Files.lines(exampleFile)
        		.flatMap(line -> Stream.of(line.split(" ")))
        		.map(removeSpecialCharsn)
        		.filter( string -> string.length() > 3)
        		.sorted()								// Sortierung ist hier unnötig, da  sie verloren geht
        		.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
        
        System.out.println(wordcount);
        
        // soll die Sortierung behalten werden: TreeMap 
        TreeMap<String, Long> wordcountsorted = Files.lines(exampleFile)
        		.flatMap(line -> Stream.of(line.split(" ")))
        		.map(removeSpecialCharsn)
        		.filter( string -> string.length() > 3)
        		//.sorted()								// Sortierung ist hier unnötig, da  sie verloren geht
        		.collect(Collectors.groupingBy(Function.identity(), TreeMap::new,  Collectors.counting()));
        
        System.out.println(wordcountsorted);
        
        
        

    }
}