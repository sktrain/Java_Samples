package aufgaben_Streams_1;

import java.util.ArrayList;
import java.util.List;

public class Aufgabe_6_loes {

	private static List<Person> createDemoData() {
		List<Person> persons = new ArrayList<>();
		persons.add(new Person("Michael", 44));
		persons.add(new Person("Barbara", 41, Gender.FEMALE));
		persons.add(new Person("Lili", 17, Gender.FEMALE));
		persons.add(new Person("Tom", 8));
		persons.add(new Person("Maike", 22, null, null));
		persons.add(null);
		persons.add(new Person("Björn", 7));
		persons.add(new Person("Max", 45, Gender.MALE, "Berlin"));
		return persons;
	}

	public static void main(String[] args) {

		// a) Übertragen Sie die Namen aller Personen, die männlich, erwachsen und deren
		// Name mit "M" beginnt in ein Array.

		List<Person> persons = createDemoData();

		String[] personsM = persons.stream()
				.filter(person -> person != null)
				.filter(person -> person.getGender() != null)
				.filter(person -> person.getGender() == Gender.MALE)
				.filter(person -> person.getAge() >= 18)
				.map(Person::getName)
				.filter(string -> string.charAt(0) == 'M')
				.toArray(i -> new String[i]);


		for (String s: personsM ) {
			System.out.println(s);
		}
		
		
		// b) Lassen Sie sich die Zwischenergebnisse der Pipeline zusätzlich ausgeben.
		String[] personsS = persons.stream()
				.filter(person -> person != null)
				.peek( person -> {
					try {
						System.out.println(person);
					} catch (NullPointerException e) {
						System.err.println("NullPointer catched");
					}

				})   //da die toString bei fehlendem Gender NullPointer wirft
				.filter(person -> person.getGender() != null)
				.peek(System.out::println)
				.filter(person -> person.getGender() == Gender.MALE)
				.peek(System.out::println)
				.filter(person -> person.getAge() >= 18)
				.peek(System.out::println)
				.map(Person::getName)
				.peek(System.out::println)
				.filter(string -> string.charAt(0) == 'M')
				.peek(System.out::println)
				.toArray( i -> new String[i]);

		for (String s: personsS ) {
			System.out.println(s);
		}
	}

}