package aufgaben_Streams_1;

import java.util.Arrays;
import java.util.List;
import java.util.OptionalInt;


public class Aufgabe_4_loes 
{	
	public static void main(String[] args) 
	{
		List<String> names = Arrays.asList("Mike", "Stefan", "Nikolaos", "Erika", "Otto");
		
		
		//a) Ermitteln Sie die Länge der Zeichenketten und davon das Maximum.

		OptionalInt maxvalue = names.stream().   // Stream<String>
						mapToInt(String::length).  		// IntStream
						max();
		
		maxvalue.ifPresentOrElse(System.out::println, ()->System.out.println("kein Maximum vorhanden"));
		
		
		
		//b) Summe der Zeichenkettenlängen	
		
		int sumvalue = names.stream().   // Stream<String>
				mapToInt(String::length).  		// IntStream
				sum();
		System.out.println(sumvalue);
	}
}

