 IntelliJ-Projekt Muster_Mitarbeiter mit den diversen Varianten bzw.
 Schritten für die Aufgabe "Mitarbeiter-Verwaltung"
(inklusive des JDBC-Treibers für H2-Database im "dependencies-Ordner")