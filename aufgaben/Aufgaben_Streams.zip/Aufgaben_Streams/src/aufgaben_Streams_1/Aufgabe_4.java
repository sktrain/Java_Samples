package aufgaben_Streams_1;

import java.util.Arrays;
import java.util.List;
import java.util.OptionalInt;


public class Aufgabe_4 
{	
	public static void main(String[] args) 
	{
		List<String> names = Arrays.asList("Mike", "Stefan", "Nikolaos", "Erika", "Otto");
		
		
		//a) Ermitteln Sie die Länge der Zeichenketten und davon das Maximum.

		
		
		
		
		//b) Summe der Zeichenkettenlängen	
		
		
	}
}

