package aufgaben_Streams_1;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Aufgabe_7 {

	public static void main(String[] args) {

		final String[] namesArray = { "Tim", "Tom", "Andy", "Mike", "Merten" };
		
		
		// a) 	Gruppieren Sie das Ergebnis des Streams nach dem Anfangsbuchstaben, sodass wir
		// folgendes Ergebnis erhalten: A=[Andy], T=[Tim, Tom], M=[Mike, Merten]

		
		
		// b)	Teilen Sie den Inhalt gemäß einer vorgegebenen Länge, sodass wir
		// folgende Ausgabe erhalten: false=[Andy, Mike, Merten], true=[Tim, Tom]
		
		
		
		// c)	Gruppieren Sie den Inhalt nach Anfangsbuchstaben und summieren
		// Sie die Anzahl der Vorkommen, sodass wir diese Ausgabe erhalten: A=1, T=2, M=2

	}

}