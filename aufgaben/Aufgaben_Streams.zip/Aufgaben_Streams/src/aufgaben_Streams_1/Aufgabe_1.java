package aufgaben_Streams_1;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Aufgabe_1 {

	public static void main(String[] args) {

		String[] namesArray = { "Tim", "Tom", "Andy", "Mike", "Merten" };
		List<String> names = Arrays.asList(namesArray);
		
		Stream<String> streamFromArray = null;	// ... TODO ...
		Stream<String> streamFromList = null;	// ... TODO ...
		Stream<String> streamFromValues = null;	// ... TODO ...
		
		
		Stream<String> filtered = null;	// ... TODO ...
		Stream<String> mapped = null;	// ... TODO ...

	}

}
