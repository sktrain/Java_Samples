package aufgaben_Streams_1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class Aufgabe_9
{
    public static void main(String[] args) throws IOException
    {
    	
    	Path exampleFile = Paths.get("src/aufgaben_Streams_1/Example.txt");
    	
    	
    	// a) Es sollen nur die Worte aus der Textdatei "Example.txt" sortiert in einer Liste gespeichert werden,
    	// deren Länge mindestens 4 ist. Die Satzzeichen (, : . ? !) sind zu eliminieren.
    	
    	
        

        
        
        
        // b) Kann für das Ergebnis auch zielgerichtet eine ArrayList spezifiziert werden?
        
        
        
        
        
        // c) Können Sie auch mit Hilfe eines geeigneten Collectors die Worthäufigkeiten speichern?
       
      
        

    }
}