package aufgaben_Streams_1;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;



public class Aufgabe_5
{
    public static void main(final String[] args)
    {
        final List<Person> persons = new ArrayList<>();
        persons.add(new Person("Tim", 10));
        persons.add(new Person("Trude", 20));
        persons.add(new Person("Tomas", 30));
        persons.add(new Person("Max", 40));
        
        
        // a) Berechnen Sie das durchschnittliche Alter der Personen, deren Name mit einem "T" beginnt
        
        
        
        
        // b) Gibt es Personen in der Liste, deren Name ein "u" enthält?
        
       

        
    }
}