package aufgaben_Streams_1;

import java.util.stream.IntStream;

public class Aufgabe_8 {
	
	public static void main(String[] args) {
		
		final IntStream ints = IntStream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		
		//....TODO....
	}

}
