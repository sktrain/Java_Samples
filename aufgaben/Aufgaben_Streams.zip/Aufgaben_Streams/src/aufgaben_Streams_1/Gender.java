package aufgaben_Streams_1;


public enum Gender
{
    MALE, FEMALE;
}