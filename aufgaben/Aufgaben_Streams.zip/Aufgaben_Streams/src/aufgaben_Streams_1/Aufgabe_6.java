package aufgaben_Streams_1;

import java.util.ArrayList;
import java.util.List;

public class Aufgabe_6 {

	private static List<Person> createDemoData() {
		List<Person> persons = new ArrayList<>();
		persons.add(new Person("Michael", 44));
		persons.add(new Person("Barbara", 41, Gender.FEMALE));
		persons.add(new Person("Lili", 17, Gender.FEMALE));
		persons.add(new Person("Tom", 8));
		persons.add(new Person("Maike", 22, null, null));
		persons.add(null);
		persons.add(new Person("Björn", 7));
		persons.add(new Person("Max", 45, Gender.MALE, "Berlin"));
		return persons;
	}

	public static void main(String[] args) {

		// a) Übertragen Sie die Namen aller Personen, die männlich, erwachsen und deren
		// Name mit "M" beginnt in ein Array.

		
		
		
		// b) Lassen Sie sich die Zwischenergebnisse der Pipeline zusätzlich ausgeben.
		
	}

}