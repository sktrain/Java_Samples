/* Aufgabe:
 * Erweiterung von Aufgabe 3:
 * Speichern Sie die 4 Rechenarten (+ , - , *, /) mit Hilfe "intBinaryOperator" in einer Map 
 * respektive einem Enum und verwenden Sie diese in der RechnerAnwendung.
 */

package aufgaben_Lambdas_3_4;

import java.awt.FlowLayout;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.IntBinaryOperator;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class MathFrame_Map extends JFrame {
	
	//todo
}
