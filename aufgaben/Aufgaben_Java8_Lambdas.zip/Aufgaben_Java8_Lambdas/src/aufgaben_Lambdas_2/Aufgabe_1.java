package aufgaben_Lambdas_2;

import java.util.function.IntPredicate;
import java.util.function.Predicate;

public class Aufgabe_1 {

	public static void main(String[] args) {

		// a)
		Predicate<Integer> isEven = null; // ... TODO ...
				
		Predicate<Integer> isNull = null; // ... TODO ...
				
		IntPredicate isPositive = null; // ... TODO ...
		
		
		// b)
		Predicate<String> isShortWord = null;  // ... TODO ...
		
		
		
		// c)
		// ... TODO ...
	
		
		

	}

}
