package aufgaben_Lambdas_2;

public class Aufgabe_2 {

	public static void main(String[] args) {

		//use class Person

	}

}
