package aufgaben_Lambdas_3_2;

public class Application {

	public static void main(String[] args) {
		new MathFrame();
	}
	
}
