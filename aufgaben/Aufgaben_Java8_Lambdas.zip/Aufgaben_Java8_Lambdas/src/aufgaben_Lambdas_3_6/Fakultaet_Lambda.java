/*
 * Aufgabe: Realisierung der rekursiven Variante der Fakultaetsfunktion via Lambda und
 * funktionalem Interface java.util.function.IntFunction
 */

package aufgaben_Lambdas_3_6;

public class Fakultaet_Lambda {
	
	
	
	public static int fakrek(int i) {
		if ( i==1) return 1;
		else return i* fakrek(i-1);
	}
	
	public static void main( String[] args ) {
		System.out.println( fakrek( 5 ) ); //120
	}
}
