package sk.train.mav;

import java.math.BigDecimal;
import java.time.LocalDate;

public abstract class Mitarbeiter {
	
	//Datenattribute
	
	private int persnr = 1;
	private String vorname;
	private String nachname = "Muster";
	private LocalDate gebdatum = LocalDate.of(2000, 1, 1);
	private LocalDate einstdatum;
	private Geschlecht g = Geschlecht.D;
	
	public Mitarbeiter(int persnr, String vorname, String nachname, LocalDate gebdatum, LocalDate einstdatum,
			Geschlecht g) {
		super();
		this.persnr = persnr;
		this.vorname = vorname;
		this.nachname = nachname;
		this.gebdatum = gebdatum;
		this.einstdatum = einstdatum;
		this.g = g;
	}
	
	
	public Mitarbeiter(int persnr, String vorname, String nachname) {
		super();
		this.persnr = persnr;
		this.vorname = vorname;
		this.nachname = nachname;
	}
	
	//abstrakte Vorschrift
	public abstract BigDecimal getGehalt();


	public int getPersnr() {
		return persnr;
	}

	public void setPersnr(int persnr) {
		this.persnr = persnr;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public LocalDate getGebdatum() {
		return gebdatum;
	}

	public void setGebdatum(LocalDate gebdatum) {
		this.gebdatum = gebdatum;
	}

	public LocalDate getEinstdatum() {
		return einstdatum;
	}

	public void setEinstdatum(LocalDate einstdatum) {
		this.einstdatum = einstdatum;
	}

	public Geschlecht getG() {
		return g;
	}

	public void setG(Geschlecht g) {
		this.g = g;
	}


	@Override
	public String toString() {
		return "Mitarbeiter [persnr=" + persnr + ", vorname=" + vorname + ", nachname=" + nachname + ", gebdatum="
				+ gebdatum + ", einstdatum=" + einstdatum + ", g=" + g + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((einstdatum == null) ? 0 : einstdatum.hashCode());
		result = prime * result + ((g == null) ? 0 : g.hashCode());
		result = prime * result + ((gebdatum == null) ? 0 : gebdatum.hashCode());
		result = prime * result + ((nachname == null) ? 0 : nachname.hashCode());
		result = prime * result + persnr;
		result = prime * result + ((vorname == null) ? 0 : vorname.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Mitarbeiter other = (Mitarbeiter) obj;
		if (einstdatum == null) {
			if (other.einstdatum != null)
				return false;
		} else if (!einstdatum.equals(other.einstdatum))
			return false;
		if (g != other.g)
			return false;
		if (gebdatum == null) {
			if (other.gebdatum != null)
				return false;
		} else if (!gebdatum.equals(other.gebdatum))
			return false;
		if (nachname == null) {
			if (other.nachname != null)
				return false;
		} else if (!nachname.equals(other.nachname))
			return false;
		if (persnr != other.persnr)
			return false;
		if (vorname == null) {
			if (other.vorname != null)
				return false;
		} else if (!vorname.equals(other.vorname))
			return false;
		return true;
	}

//	@Override
//	public String toString() {
//		return vorname+":"+nachname;
//	}
	
	

}
