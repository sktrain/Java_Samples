package sk.train.mav;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Random;

public class Mitarbeiterverwaltung {
	
	private Mitarbeiter[] maarray;
	private ArrayList<Mitarbeiter> malist;
	
	public Mitarbeiterverwaltung() {
		// Liste und/oder Array initialisieren
		malist = new ArrayList<>();
		maarray = new Mitarbeiter[100];
		
		//Schleife 100 MA erzeugen , 50:50 Arbeiter:Fixgehalt
		//und Collection f�llen
		for (int i = 0; i <100; ++i) {
			if (i%2 == 0) {
				Mitarbeiter m = new FixgehaltMitarbeiter(i, "Erika", "Musterfrau"+i, 
						                                 LocalDate.of(1950+i, 1+new Random().nextInt(11), 1)
						                                 , LocalDate.of(2000, 1, 1), 
						                                 Geschlecht.W, 
						                                 new BigDecimal(new Random().nextInt(10000)));
				System.out.println(m);
				malist.add(m);
				maarray[i] = m;						
			} else {
				Mitarbeiter a = new Arbeiter(i, "Max", "Maulwurf"+i, 
                        LocalDate.of(1950+i, 1+new Random().nextInt(11), 1)
                        , LocalDate.of(2000, 1, 1), 
                        Geschlecht.W, 
                        new BigDecimal(100),
                        new BigDecimal(1+new Random().nextInt(100)));
				malist.add(a);
				maarray[i] = a;	
				
			}
		}
	}

	public Mitarbeiter[] getMaarray() {
		return maarray;
	}

	public ArrayList<Mitarbeiter> getMalist() {
		return malist;
	}
	
	public BigDecimal getGehaltsSumme() {
		BigDecimal erg = BigDecimal.ZERO;
		for (Mitarbeiter m : malist) {
			erg = erg.add(m.getGehalt());
		}
		return erg;
	}
	

}
