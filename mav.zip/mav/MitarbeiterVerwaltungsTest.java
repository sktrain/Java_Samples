package sk.train.mav;

public class MitarbeiterVerwaltungsTest {
	
	public static void main(String[] args) {
		
		Mitarbeiterverwaltung mv = new Mitarbeiterverwaltung();
		
		for (Mitarbeiter m : mv.getMalist()) {
			System.out.println(m);
		}
		
		System.out.println("\n*********************************************\n");
		
		for (Mitarbeiter m : mv.getMaarray()) {
			System.out.println(m);
		}
		
		System.out.println("\n*********************************************\n");
		
		System.out.println(mv.getGehaltsSumme());
	}

}
