package sk.train.mav;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Arbeiter extends Mitarbeiter{
	
	private BigDecimal stdanzahl;
	private BigDecimal stdlohn;
	
	public Arbeiter(int persnr, String vorname, String nachname, LocalDate gebdatum, 
			        LocalDate einstdatum, Geschlecht g,
			        BigDecimal stdanzahl, BigDecimal stdlohn) {
		super(persnr, vorname, nachname, gebdatum, einstdatum, g);
		this.stdanzahl = stdanzahl;
		this.stdlohn = stdlohn;
	}

	public BigDecimal getStdanzahl() {
		return stdanzahl;
	}

	public void setStdanzahl(BigDecimal stdanzahl) {
		this.stdanzahl = stdanzahl;
	}

	public BigDecimal getStdlohn() {
		return stdlohn;
	}

	public void setStdlohn(BigDecimal stdlohn) {
		this.stdlohn = stdlohn;
	}

	@Override
	public BigDecimal getGehalt() {
		// TODO Auto-generated method stub
		return stdanzahl.multiply(stdlohn);
	}

	

	
	
	
	

}
