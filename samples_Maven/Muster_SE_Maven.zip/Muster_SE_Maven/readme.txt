Samples zur Java SE auf
Basis eines Maven Projekts mit aktuellen Plugin-Versionen vom Januar 2023
+ Jupiter-Dependencies

+  H2-Database Treiber (momentan nur für H2, nicht für andere DBMS)
