package dynamicproxy;

public interface MathService {

	int add(int a, int b);

	int diff(int a, int b);

}