 Maven-Variante des Projekts Muster_Mitarbeiter 
 auf Basis eines Maven Projekt mit aktuellen Plugin-Versionen vom
 September 2024 + Jupiter-Dependencies