public class IEEEremainder {
  public static void main( String[] args ) {
    double a = 44.0;
    double b = 2.2;

    System.out.println( a % b );
    System.out.println( Math.IEEEremainder( a, b ) );
  }
}