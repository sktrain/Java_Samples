package com.tutego.insel.nongeneric;

public class Player {
  
  public String name;
  public Pocket rightPocket;
  public Pocket leftPocket;
}
