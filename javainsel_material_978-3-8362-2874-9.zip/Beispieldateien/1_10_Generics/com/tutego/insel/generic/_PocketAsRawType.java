package com.tutego.insel.generic;

public class _PocketAsRawType
{
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public static void main( String[] args )
  {
    Pocket p = new Pocket();
    p.set( "Roh macht nicht froh" );
  }
}
