package com.tutego.insel.game.vb;

public class Room {
  public Player player;
}
