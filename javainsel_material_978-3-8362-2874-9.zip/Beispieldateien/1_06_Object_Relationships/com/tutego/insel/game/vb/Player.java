package com.tutego.insel.game.vb;

public class Player {
  public Room room;
}
