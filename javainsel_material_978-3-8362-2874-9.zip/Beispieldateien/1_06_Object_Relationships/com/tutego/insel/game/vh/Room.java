package com.tutego.insel.game.vh;

public class Room extends GameObject { }
