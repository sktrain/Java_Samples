package com.tutego.insel.game.vl;

interface Buyable {
  double price();
}