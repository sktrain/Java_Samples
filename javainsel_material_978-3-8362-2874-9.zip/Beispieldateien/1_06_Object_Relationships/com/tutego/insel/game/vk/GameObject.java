package com.tutego.insel.game.vk;

abstract class GameObject { }
