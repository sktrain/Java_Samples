package com.tutego.insel.game.vk;

interface Buyable {
  double price();
}