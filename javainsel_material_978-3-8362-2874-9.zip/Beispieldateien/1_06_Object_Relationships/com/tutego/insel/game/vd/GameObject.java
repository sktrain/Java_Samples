package com.tutego.insel.game.vd;

public class GameObject {
  public String name;
}
