package com.tutego.insel.game.vd;

public class TypeSuptype {

  @SuppressWarnings("unused")
  public static void main( String[] args ) {
    Player     playerIsPlayer     = new Player();
    GameObject gameObjectIsPlayer = new Player();
    Object     objectIsPlayer     = new Player();
    Room       roomIsRoom         = new Room();
    GameObject gameObjectIsRoom   = new Room();
    Object     objectIsRoom       = new Room();
  }
}
