package com.tutego.insel.game.va;

public class Room { }
