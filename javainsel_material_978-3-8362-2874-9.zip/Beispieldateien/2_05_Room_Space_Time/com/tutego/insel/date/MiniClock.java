package com.tutego.insel.date;

class MiniClock {
  public static void main( String[] args ) {
    System.out.println( new java.util.Date() ); // Fri Jun 08 18:58:21 CEST 2012
  }
}