public class InitStaticVariable {

  static int staticInt;
  
  static {
    staticInt = 0;
  }
}