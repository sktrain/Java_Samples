public class Grob extends Alien {
  public Grob() {
    super( "Locutus" );    // Alle Grobs leben auf Locutus 
  }
}