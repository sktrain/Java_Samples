package com.tutego.insel.game.v2;

class Player {
  String name;
  String item;
}
