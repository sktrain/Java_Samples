package com.tutego.insel.game.v5;

class Playground {

  public static void main( String[] args ) {
    Player spongebobby = new Player();
    spongebobby.setName( "Spongebobby" );
    spongebobby.setItem( "Schnecke" );
  }
}
