package com.tutego.insel.protectedb;

//import com.tutego.insel.protecteda.C;

class D {
//  int d = C.c;   // The field C.c is not visible
}
