package com.tutego.insel.protectedb;

class B {
//  A a;  // A cannot be resolved to a type
}
