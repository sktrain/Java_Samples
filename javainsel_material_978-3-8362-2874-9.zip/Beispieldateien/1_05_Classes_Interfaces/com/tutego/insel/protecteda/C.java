package com.tutego.insel.protecteda;

public class C {
  static int c;
}
