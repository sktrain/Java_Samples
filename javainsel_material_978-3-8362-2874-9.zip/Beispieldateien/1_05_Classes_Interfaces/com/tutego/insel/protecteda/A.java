package com.tutego.insel.protecteda;

class A { }
