package com.tutego.insel.thread;

public class IPlusPlus {
  static int i;
  static void foo() {
    i++;
  }
}
