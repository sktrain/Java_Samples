public class SystemOutErr {
  public static void main( String[] args ) {
    System.out.println( "Das ist eine normale Ausgabe" );
    System.err.println( "Das ist eine Fehlerausgabe" );
  }
}
