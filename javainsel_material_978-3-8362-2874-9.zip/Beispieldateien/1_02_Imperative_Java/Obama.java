public class Obama {

  @SuppressWarnings("unused")
  public static void main( String[] args ) {
    String  name = "Barack Hussein Obama II";
    int     age = 48;
    double  income = 400000;  
    char    gender = 'm';
    boolean isPresident = true;
  }
}
