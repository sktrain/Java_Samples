class Application2 {

  public static void main( String[] args ) {
    // Start des Programms

    System.out.println( "Hallo Javanesen" );

    // End des Programms
  }
}
