public class WhileTrue {
  public static void main( String[] args ) {
    while ( true ) {
      // immer wieder und immer wieder
    }
  }
}

