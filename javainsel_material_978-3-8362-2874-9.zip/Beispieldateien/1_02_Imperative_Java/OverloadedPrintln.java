public class OverloadedPrintln {

  public static void main( String[] args ) {
    System.out.println( "Verhaften Sie die üblichen Verdächtigen!" );
    System.out.println( true );
    System.out.println( -273 );
    System.out.println();                // Gibt eine Leerzeile aus
    System.out.println( 1.6180339887498948 );
  }
}
