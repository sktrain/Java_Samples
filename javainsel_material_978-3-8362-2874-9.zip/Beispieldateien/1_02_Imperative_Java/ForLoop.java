public class ForLoop {

  public static void main( String[] args ) {
    for ( int i = 1; i < 11; i++ )        // i loop counter
      System.out.println( i );
  }
}