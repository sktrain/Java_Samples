public class FirstVariable {

  @SuppressWarnings("unused")
  public static void main( String[] args ) {
    int     age;                 // Alter
    double  income;              // Einkommen
    char    gender;              // Geschlecht (f oder m)
    boolean isPresident;         // Ist Präsident (true oder false)
    String  name;                // Name
  }
}
