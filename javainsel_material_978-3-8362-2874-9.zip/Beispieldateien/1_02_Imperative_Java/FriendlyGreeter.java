class FriendlyGreeter {

  static void greet() {
    System.out.println( "Guten Morgen. Oh, und falls wir uns nicht mehr" +
                        " sehen, guten Tag, guten Abend und gute Nacht!" );
  }

  public static void main( String[] args ) {
    greet();
  }
}
