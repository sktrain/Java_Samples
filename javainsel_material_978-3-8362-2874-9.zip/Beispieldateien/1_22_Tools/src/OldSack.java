@SuppressWarnings( "deprecation" )
public class OldSack {
  java.util.Date d = new java.util.Date( 62, 3, 4 );
}
