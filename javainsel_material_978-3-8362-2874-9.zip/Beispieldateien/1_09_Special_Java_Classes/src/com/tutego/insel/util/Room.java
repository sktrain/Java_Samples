package com.tutego.insel.util;

public class Room {

  private int sqm;

  public Room( int sm ) {
    this.sqm = sm;}

  public int getSqm() {
    return sqm;
  }
}
