package com.tutego.insel.junit.util;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith( Suite.class )
@Suite.SuiteClasses(
{
    StringUtilsTest.class, FixtureDemoTest.class
} )
public class PackageTest
{
}
