package com.tutego.insel.junit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith( Suite.class )
@Suite.SuiteClasses(
{
    com.tutego.insel.junit.util.PackageTest.class
} )
public class PackageTest
{
}
