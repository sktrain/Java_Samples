public class _StringLiteral {

  public static void main( String[] args ) {
    char[] vocalsArray = { 'a', 'e', 'i', 'o', 'u' };

    String vocal = new String( vocalsArray );
    System.out.println( vocal );
  }
}
