class Windows7KeyGenerator {
  public String generateKey() {
    throw new UnsupportedOperationException();
  }
}
