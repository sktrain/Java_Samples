public class SystemExitDemo {
  public static void main( String[] args ) {
    System.exit( 42 );
  }
}